# -*- coding: utf-8 -*-
"""
iztro-py 国际化 (i18n) 用法示例

演示内容：
1. 默认语言与 get_language / set_language
2. 翻译函数 t() 及按调用临时指定语言
3. 直接用 language 参数生成不同语言的星盘
4. 宫位 / 星曜对象的 translate_* 方法
5. 不支持语言时的优雅降级（回退到 zh-CN）

支持的语言：zh-CN, zh-TW, en-US, ja-JP, ko-KR, vi-VN
"""

import os
import sys
import warnings

sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../src")))

from iztro_py import astro
from iztro_py.i18n import get_language, set_language, t


def section(title: str) -> None:
    print("\n" + "=" * 72)
    print(title)
    print("=" * 72)


# ---------------------------------------------------------------------------
# 1. 默认语言
# ---------------------------------------------------------------------------
section("1. 默认语言 (Default language)")
print(f"当前语言 get_language(): {get_language()}")
print(f"紫微 -> {t('stars.major.ziweiMaj')}")
print(f"命宫 -> {t('palaces.soulPalace')}")

# ---------------------------------------------------------------------------
# 2. 切换全局语言 + t() 临时指定语言
# ---------------------------------------------------------------------------
section("2. 切换语言 (set_language) 与按调用指定语言")
for lang in ["zh-CN", "zh-TW", "en-US", "ja-JP", "ko-KR", "vi-VN"]:
    set_language(lang)
    # t() 不传 lang 时使用全局语言；也可显式传 lang 覆盖
    name = t("stars.major.ziweiMaj")
    palace = t("palaces.soulPalace", lang)
    print(f"  {lang}: 紫微={name:10s} 命宫={palace}")

# 用完恢复默认，避免影响后续示例
set_language("zh-CN")

# ---------------------------------------------------------------------------
# 3. 直接生成不同语言的星盘
# ---------------------------------------------------------------------------
section("3. 多语言星盘 (astro.by_solar language=...)")
for lang in ["zh-CN", "en-US", "ja-JP"]:
    chart = astro.by_solar("2000-8-16", 6, "男", language=lang)
    soul = chart.get_soul_palace()
    stars = ", ".join(s.translate_name(lang) for s in soul.major_stars) or "-"
    print(
        f"  {lang}: 命宫={soul.translate_name(lang):14s} "
        f"{soul.translate_heavenly_stem(lang)}{soul.translate_earthly_branch(lang)} "
        f"[{stars}]"
    )

# ---------------------------------------------------------------------------
# 4. 对象级翻译方法
# ---------------------------------------------------------------------------
section("4. 宫位 / 星曜对象的 translate_* 方法")
chart = astro.by_solar("2000-8-16", 6, "男")
for palace in chart.palaces[:4]:
    cn = palace.translate_name("zh-CN")
    en = palace.translate_name("en-US")
    print(f"  index={palace.index:2d}  {cn:8s} / {en}")

# ---------------------------------------------------------------------------
# 5. 不支持的语言 -> 优雅降级到 zh-CN（仅告警，不报错）
# ---------------------------------------------------------------------------
section("5. 不支持语言的降级 (fallback)")
with warnings.catch_warnings(record=True) as caught:
    warnings.simplefilter("always")
    set_language("fr-FR")  # 不支持
    print(f"  请求 fr-FR 后实际语言: {get_language()}")
    if caught:
        print(f"  收到告警: {caught[0].category.__name__}")

set_language("zh-CN")
print("\n演示完成 / Demo completed!")
